module.exports = {

"[project]/app/admin/loading.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Loading)
});
function Loading() {
    return null;
}
}}),

};

//# sourceMappingURL=app_admin_loading_tsx_d4a2d118._.js.map