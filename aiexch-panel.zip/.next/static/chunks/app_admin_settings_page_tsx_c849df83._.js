(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_admin_settings_page_tsx_c849df83._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_admin_settings_page_tsx_c849df83._.js",
  "chunks": [
    "static/chunks/_b56e325a._.js",
    "static/chunks/node_modules_4808dd4c._.js"
  ],
  "source": "dynamic"
});
