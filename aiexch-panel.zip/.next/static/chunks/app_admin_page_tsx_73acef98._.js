(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_admin_page_tsx_73acef98._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_admin_page_tsx_73acef98._.js",
  "chunks": [
    "static/chunks/app_admin_page_tsx_9b891d59._.js"
  ],
  "source": "dynamic"
});
