(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_admin_page_tsx_c849df83._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_admin_page_tsx_c849df83._.js",
  "chunks": [
    "static/chunks/components_ui_c155fbcb._.js",
    "static/chunks/components_admin_user-management_tsx_b6db708c._.js",
    "static/chunks/components_admin_game-management_tsx_3ca3f919._.js",
    "static/chunks/components_admin_tournament-management_tsx_07700929._.js",
    "static/chunks/components_admin_white-label-settings_tsx_8ca0908a._.js",
    "static/chunks/components_admin_analytics-reports_tsx_15545366._.js",
    "static/chunks/components_admin_promotions-management_tsx_212da597._.js",
    "static/chunks/components_admin_58555e37._.js",
    "static/chunks/_0bd08987._.js",
    "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
    "static/chunks/node_modules_lodash_ff39e716._.js",
    "static/chunks/node_modules_recharts_es6_5ec05582._.js",
    "static/chunks/node_modules_@radix-ui_ad16560e._.js",
    "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
    "static/chunks/node_modules_b514c83c._.js"
  ],
  "source": "dynamic"
});
